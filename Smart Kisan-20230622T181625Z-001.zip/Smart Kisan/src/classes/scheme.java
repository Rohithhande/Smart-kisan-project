package classes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class scheme
 */
@WebServlet("/scheme")
public class scheme extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection connection=DbConnection.getConnection();
		String sname=request.getParameter("sname");
	
		String distname=request.getParameter("distname");
		String link=request.getParameter("link");
		try{
			PreparedStatement ps=connection.prepareStatement("insert into SCHEME values(?,?,?)");
		
			ps.setString(1, sname);
			ps.setString(2, distname);
			ps.setString(3, link);
			ps.executeUpdate();
			System.out.println("Scheme entry succesfull");
			response.sendRedirect("adminhome.jsp");
		}
		catch (Exception e2) 
		{
			System.out.println(e2);
		}  
}
}
