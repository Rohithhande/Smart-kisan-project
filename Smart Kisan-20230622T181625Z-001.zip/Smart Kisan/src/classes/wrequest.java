package classes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.xml.internal.ws.api.ha.StickyFeature;

import classes.Mail;
@WebServlet("/wrequest")
public class wrequest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("111111");
		Connection connection=DbConnection.getConnection();
		System.out.println("22222");
		String  name=request.getParameter("name");
		String  email=request.getParameter("email");
		String  phone=request.getParameter("phone");
		String  quan=request.getParameter("quan");
		String  addr=request.getParameter("addr");
		System.out.println(name);
		
		
		try{  
			
			PreparedStatement ps=connection.prepareStatement("insert into WREQUEST values(?,?,?,?,?)");
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, phone);
			ps.setString(4, quan);
			ps.setString(5, addr);
			
		
			ps.executeUpdate();
			
			String maildata=name+" "+email+" "+phone+" "+quan+" "+addr;
			new Mail(maildata,"vinayakshet227@gmail.com");
			response.sendRedirect("wholesalerpage.jsp?msg=added successfully");
		 
		}
		catch (Exception e2) 
		{
			System.out.println(e2);
		}  

}
	
}
