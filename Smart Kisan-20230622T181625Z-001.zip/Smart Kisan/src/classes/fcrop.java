package classes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Addcrops
 */
@WebServlet("/facrop")
public class fcrop extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection connection=DbConnection.getConnection();
		String cname=request.getParameter("cname");
		String distname=request.getParameter("distname");
		String price=request.getParameter("price");
		try{
			PreparedStatement ps=connection.prepareStatement("insert into facrop values(?,?,?)");
		ps.setString(1, cname);
			ps.setString(2, distname);
			ps.setString(3, price);
			ps.executeUpdate();
			System.out.println("crop entry succesfull");
			response.sendRedirect("userhome.jsp");
		}
		catch (Exception e2) 
		{
			System.out.println(e2);
		}  
}
}
